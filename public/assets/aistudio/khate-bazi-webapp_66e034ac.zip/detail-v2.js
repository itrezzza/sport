(() => {
  'use strict';

  const byId = id => document.getElementById(id);
  const overlay = byId('matchOverlay');
  const closeButton = byId('closeDetail');
  const panes = ['Timeline', 'Stats', 'Lineup'];
  let serial = 0;
  let controller = null;
  let returnFocus = null;
  let activeHighlight = null;
  let highlightController = null;
  let highlightSerial = 0;

  function text(value) {
    return value == null ? '' : String(value);
  }

  function safeUrl(value, hosts) {
    try {
      const url = new URL(value);
      return url.protocol === 'https:' && hosts.includes(url.hostname) ? url.href : '';
    } catch { return ''; }
  }

  function matchPage(value) {
    try {
      if (typeof value !== 'string' || !value.startsWith('/') || value.startsWith('//')) return '';
      const url = new URL(value, 'https://www.varzesh3.ir');
      return url.hostname === 'www.varzesh3.ir' ? url.href : '';
    } catch { return ''; }
  }

  function message(paneId, value) {
    const box = document.createElement('div');
    box.className = 'detail-empty';
    box.textContent = value;
    byId(paneId).replaceChildren(box);
  }

  function addMeta(value) {
    if (!value) return;
    const chip = document.createElement('span');
    chip.textContent = value;
    byId('detailMeta').append(chip);
  }

  function fillTeam(id, team, fallback) {
    const target = byId(id);
    target.replaceChildren();
    const logo = safeUrl(team?.logo, ['match-cdn.varzesh3.ir']);
    const badge = document.createElement(logo ? 'img' : 'span');
    if (logo) {
      badge.src = logo;
      badge.alt = '';
    } else {
      badge.className = 'team-fallback';
      badge.textContent = '●';
    }
    const name = document.createElement('strong');
    name.textContent = team?.name || fallback;
    target.append(badge, name);
  }

  function fillScore(host, guest) {
    const target = byId('detailScore');
    const hostCell = document.createElement('span');
    const separator = document.createElement('span');
    const guestCell = document.createElement('span');
    hostCell.textContent = text(host ?? '–');
    separator.textContent = ':';
    guestCell.textContent = text(guest ?? '–');
    target.replaceChildren(hostCell, separator, guestCell);
  }

  function closeHighlight(restoreFocus = false) {
    highlightSerial += 1;
    highlightController?.abort();
    highlightController = null;
    if (!activeHighlight) return;
    const { row, panel, trigger, player } = activeHighlight;
    player.pause();
    player.removeAttribute('src');
    player.removeAttribute('poster');
    player.load();
    panel.hidden = true;
    row.classList.remove('video-open');
    trigger.setAttribute('aria-expanded', 'false');
    activeHighlight = null;
    if (restoreFocus && trigger.isConnected) trigger.focus({ preventScroll: true });
  }

  async function openHighlight(videoId, row, panel, trigger, player, status, title) {
    if (activeHighlight?.panel === panel) { closeHighlight(true); return; }
    closeHighlight();
    const requestId = ++highlightSerial;
    highlightController = new AbortController();
    activeHighlight = { row, panel, trigger, player };
    row.classList.add('video-open');
    panel.hidden = false;
    trigger.setAttribute('aria-expanded', 'true');
    status.textContent = 'در حال آماده‌سازی ویدئوی صحنه…';
    panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    try {
      const response = await fetch('/api/varzesh3/video/' + videoId, {
        cache: 'no-store', signal: highlightController.signal
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'HTTP ' + response.status);
      if (requestId !== highlightSerial) return;
      const src = safeUrl(data.src, ['video-vcdn.varzesh3.ir']);
      if (!/\.mp4(?:\?|$)/i.test(src)) throw new Error('فایل ویدئو معتبر نیست.');
      const poster = safeUrl(data.poster, ['video-icdn.varzesh3.ir']);
      if (poster) player.poster = poster;
      title.textContent = data.title || 'ویدئوی صحنه';
      player.src = src;
      status.textContent = 'در حال بارگذاری ویدئو…';
      try { await player.play(); }
      catch { if (requestId === highlightSerial) status.textContent = 'برای شروع، دکمهٔ پخش را بزن.'; }
    } catch (error) {
      if (requestId === highlightSerial && error.name !== 'AbortError') status.textContent = 'پخش این صحنه ممکن نیست: ' + error.message;
    }
  }

  function chooseTab(name) {
    if (name !== 'Timeline') closeHighlight();
    for (const pane of panes) {
      const active = name === pane;
      byId('detailTab' + pane).setAttribute('aria-selected', String(active));
      byId('detail' + pane).hidden = !active;
    }
  }

  function eventTitle(event) {
    const description = text(event.description || event.decisionTitle);
    if (event.eventType === 1) return '⚽ گل' + (event.strickerName ? ' · ' + event.strickerName : '');
    if (event.eventType === 4) return '↔ تعویض';
    if (event.eventType === 5) return '◇ بررسی VAR';
    if (description.includes('کارت قرمز')) return '▣ کارت قرمز';
    if (description.includes('کارت زرد')) return '▣ کارت زرد';
    return '● رخداد بازی';
  }

  function renderTimeline(events, match) {
    closeHighlight();
    const target = byId('detailTimeline');
    target.replaceChildren();
    if (!Array.isArray(events) || !events.length) {
      message('detailTimeline', 'هنوز رخدادی برای این بازی ثبت نشده است.');
      return;
    }

    const summary = document.createElement('p');
    summary.className = 'detail-intro';
    summary.textContent = events.length.toLocaleString('fa-IR') + ' رخداد · ' + (match.host?.name || 'میزبان') + ' / ' + (match.guest?.name || 'میهمان');
    const timeline = document.createElement('div');
    timeline.className = 'timeline';
    let activePeriod = '';

    [...events].sort((a, b) =>
      (Number(a.rawTime) || parseInt(a.time, 10) || 0) - (Number(b.rawTime) || parseInt(b.time, 10) || 0)
    ).forEach(event => {
      const minute = Number(event.rawTime) || parseInt(event.time, 10) || 0;
      const period = minute > 90 ? 'وقت‌های اضافه' : minute > 45 ? 'نیمهٔ دوم' : 'نیمهٔ اول';
      if (period !== activePeriod) {
        const periodNode = document.createElement('div');
        periodNode.className = 'period-label';
        periodNode.textContent = period;
        timeline.append(periodNode);
        activePeriod = period;
      }

      const row = document.createElement('div');
      row.className = 'timeline-row ' + (event.side === 1 ? 'away' : 'home');
      const timeNode = document.createElement('span');
      timeNode.className = 'timeline-minute';
      timeNode.textContent = text(event.time ?? '—') + '′';
      const eventNode = document.createElement('div');
      eventNode.className = 'timeline-event';
      const heading = document.createElement('strong');
      heading.textContent = eventTitle(event);
      const description = document.createElement('p');
      description.textContent = event.description || event.decisionTitle || 'جزئیات ثبت نشده است.';
      eventNode.append(heading, description);

      const extras = [];
      if (event.assisterName) extras.push('پاس گل: ' + event.assisterName);
      if (event.matchResult) extras.push('نتیجه: ' + text(event.matchResult.host) + ' : ' + text(event.matchResult.guest));
      if (extras.length) {
        const extra = document.createElement('small');
        extra.className = 'event-extra';
        extra.textContent = extras.join(' · ');
        eventNode.append(extra);
      }

      const video = safeUrl(event.videoLink, ['video.varzesh3.ir']);
      const videoId = String(event.videoId || video.match(/\/video\/(\d+)\/?(?:\?.*)?$/)?.[1] || '');
      if (video && /^\d+$/.test(videoId)) {
        const trigger = document.createElement('button');
        trigger.type = 'button';
        trigger.className = 'event-video-trigger';
        trigger.setAttribute('aria-expanded', 'false');
        trigger.textContent = event.eventType === 1 ? '▶ تماشای ویدئوی گل' : '▶ تماشای صحنه';
        const panel = document.createElement('div');
        panel.className = 'event-video-panel';
        panel.id = 'event-video-' + videoId;
        panel.hidden = true;
        trigger.setAttribute('aria-controls', panel.id);
        const toolbar = document.createElement('div');
        toolbar.className = 'event-video-toolbar';
        const title = document.createElement('strong');
        title.textContent = eventTitle(event);
        const dismiss = document.createElement('button');
        dismiss.type = 'button';
        dismiss.setAttribute('aria-label', 'بستن ویدئوی صحنه');
        dismiss.textContent = '×';
        dismiss.onclick = () => closeHighlight(true);
        toolbar.append(title, dismiss);
        const stage = document.createElement('div');
        stage.className = 'event-video-stage';
        const player = document.createElement('video');
        player.controls = true;
        player.playsInline = true;
        player.preload = 'metadata';
        stage.append(player);
        const status = document.createElement('p');
        status.className = 'event-video-status';
        player.addEventListener('playing', () => { if (activeHighlight?.player === player) status.textContent = ''; });
        player.addEventListener('error', () => { if (activeHighlight?.player === player) status.textContent = 'بارگذاری ویدئو ناموفق بود.'; });
        panel.append(toolbar, stage, status);
        trigger.onclick = () => openHighlight(videoId, row, panel, trigger, player, status, title);
        eventNode.append(trigger, panel);
      }
      row.append(timeNode, eventNode);
      timeline.append(row);
    });

    target.append(summary, timeline);
  }

  function renderStats(sections, match) {
    if (!Array.isArray(sections) || !sections.length) {
      message('detailStats', 'آمار این مسابقه در منبع فعلی موجود نیست. صفحهٔ کامل بازی را باز کن.');
      return;
    }
    const section = sections.find(item => /مجموع|کل/.test(item.title || '')) || sections[sections.length - 1];
    const entries = [section.possession, ...(section.items || [])].filter(item => item?.title);
    if (!entries.length) {
      message('detailStats', 'هنوز آماری برای این بازی منتشر نشده است.');
      return;
    }
    const target = byId('detailStats');
    target.replaceChildren();
    const intro = document.createElement('p');
    intro.className = 'detail-intro';
    intro.textContent = (section.title || 'مجموع بازی') + ' · ' + (match.host?.name || 'میزبان') + ' / ' + (match.guest?.name || 'میهمان');
    const list = document.createElement('div');
    list.className = 'stats-list';
    entries.forEach(entry => {
      const row = document.createElement('div');
      row.className = 'stat-row';
      const values = document.createElement('div');
      values.className = 'stat-values';
      const host = document.createElement('span');
      const title = document.createElement('span');
      const guest = document.createElement('span');
      host.textContent = text(entry.host?.value ?? '—');
      title.textContent = entry.title;
      guest.textContent = text(entry.guest?.value ?? '—');
      values.append(host, title, guest);

      let hostPercent = Number(entry.host?.percent);
      if (!Number.isFinite(hostPercent)) {
        const hostNumber = Number(entry.host?.value);
        const guestNumber = Number(entry.guest?.value);
        hostPercent = Number.isFinite(hostNumber + guestNumber) && hostNumber + guestNumber > 0
          ? 100 * hostNumber / (hostNumber + guestNumber) : 50;
      }
      hostPercent = Math.min(100, Math.max(0, hostPercent));
      const track = document.createElement('div');
      track.className = 'stat-track';
      const homeBar = document.createElement('span');
      homeBar.className = 'stat-host';
      homeBar.style.width = hostPercent + '%';
      const awayBar = document.createElement('span');
      awayBar.className = 'stat-guest';
      awayBar.style.width = (100 - hostPercent) + '%';
      track.append(homeBar, awayBar);
      row.append(values, track);
      list.append(row);
    });
    target.append(intro, list);
  }

  function playerGroup(panel, label, players) {
    if (!Array.isArray(players) || !players.length) return;
    const heading = document.createElement('h4');
    heading.textContent = label;
    const list = document.createElement('div');
    list.className = 'players';
    players.forEach(player => {
      const row = document.createElement('div');
      row.className = 'player-row';
      const name = document.createElement('span');
      name.textContent = (player.name || 'بازیکن') + (player.isCaptain ? ' · کاپیتان' : '') + (player.isManOfTheMatch ? ' ★' : '');
      const number = document.createElement('span');
      number.className = 'player-number';
      number.textContent = [player.shirtNumber, player.score ? 'امتیاز ' + player.score : ''].filter(value => value !== null && value !== '').join(' · ');
      row.append(name, number);
      list.append(row);
    });
    panel.append(heading, list);
  }

  function renderLineup(lineup, match) {
    if (!lineup?.host && !lineup?.guest) {
      message('detailLineup', 'ترکیب تیم‌ها هنوز منتشر نشده است.');
      return;
    }
    const target = byId('detailLineup');
    target.replaceChildren();
    const grid = document.createElement('div');
    grid.className = 'lineup-grid';
    for (const side of ['host', 'guest']) {
      const data = lineup[side] || {};
      const panel = document.createElement('section');
      panel.className = 'lineup-side';
      const title = document.createElement('h3');
      title.textContent = match[side]?.name || (side === 'host' ? 'میزبان' : 'میهمان');
      const formation = document.createElement('p');
      formation.className = 'lineup-meta';
      const coach = typeof data.coach === 'string' ? data.coach : data.coach?.name;
      formation.textContent = [data.formation ? 'آرایش ' + data.formation : '', coach ? 'سرمربی: ' + coach : ''].filter(Boolean).join(' · ');
      panel.append(title, formation);
      const starters = (data.formationLines || []).flatMap(line => line.players || []);
      playerGroup(panel, 'ترکیب اصلی', starters);
      playerGroup(panel, 'نیمکت', data.benchedPlayers || []);
      grid.append(panel);
    }
    target.append(grid);
  }

  function close() {
    if (overlay.hidden) return;
    closeHighlight();
    serial += 1;
    controller?.abort();
    controller = null;
    overlay.hidden = true;
    document.body.classList.remove('modal-open');
    if (returnFocus?.isConnected) returnFocus.focus({ preventScroll: true });
    returnFocus = null;
  }

  function open(match, league, sport) {
    const id = String(match?.id || '');
    if (!/^\d+$/.test(id)) return;
    closeHighlight();
    controller?.abort();
    controller = new AbortController();
    const requestId = ++serial;
    returnFocus = document.activeElement;
    overlay.hidden = false;
    document.body.classList.add('modal-open');
    byId('detailScroll').scrollTop = 0;
    byId('detailHeading').textContent = (match.host?.name || 'میزبان') + ' ـ ' + (match.guest?.name || 'میهمان');
    byId('detailLeague').textContent = league || 'مسابقه';
    fillTeam('detailHost', match.host, 'میزبان');
    fillTeam('detailGuest', match.guest, 'میهمان');
    fillScore(match.goals?.host, match.goals?.guest);
    byId('detailState').textContent = match.isLive ? '● زنده ' + (match.liveTime || '') :
      (match.goals ? (match.statusTitle || 'پایان بازی') : 'در انتظار شروع');
    byId('detailMeta').replaceChildren();
    addMeta(match.date);
    if (match.time) addMeta('شروع ' + match.time);
    const page = matchPage(match.link);
    byId('detailMatchLink').hidden = !page;
    if (page) byId('detailMatchLink').href = page;
    const stream = safeUrl(match.liveStream?.link, ['anten.ir', 'www.anten.ir']);
    byId('detailWatchLink').hidden = !stream;
    if (stream) byId('detailWatchLink').href = stream;
    chooseTab('Timeline');
    message('detailTimeline', 'در حال دریافت رخدادهای مسابقه…');
    message('detailStats', 'در حال دریافت آمار مسابقه…');
    message('detailLineup', 'در حال دریافت ترکیب تیم‌ها…');
    closeButton.focus({ preventScroll: true });

    if (sport !== 1) {
      message('detailTimeline', 'رویدادهای این رشته در API فعلی موجود نیست؛ صفحهٔ کامل مسابقه را باز کن.');
      message('detailStats', 'آمار این رشته در API فعلی موجود نیست.');
      message('detailLineup', 'ترکیب این رشته در API فعلی موجود نیست.');
      return;
    }

    fetch('/api/varzesh3/events/' + id, { cache: 'no-store', signal: controller.signal })
      .then(response => { if (!response.ok) throw new Error('HTTP ' + response.status); return response.json(); })
      .then(events => { if (serial === requestId) renderTimeline(events, match); })
      .catch(error => { if (serial === requestId && error.name !== 'AbortError') message('detailTimeline', 'دریافت رخدادها در حال حاضر ممکن نیست.'); });

    fetch('/api/varzesh3/match/' + id, { cache: 'no-store', signal: controller.signal })
      .then(response => { if (!response.ok) throw new Error('HTTP ' + response.status); return response.json(); })
      .then(details => {
        if (serial !== requestId) return;
        if (details.stadium) addMeta('ورزشگاه: ' + details.stadium);
        const referee = typeof details.referee === 'string' ? details.referee : details.referee?.name;
        if (referee) addMeta('داور: ' + referee);
        if (details.week) addMeta('هفتهٔ ' + details.week);
        if (byId('detailMatchLink').hidden) {
          const official = safeUrl(details.pageUrl, ['www.varzesh3.ir']);
          if (official) { byId('detailMatchLink').href = official; byId('detailMatchLink').hidden = false; }
        }
        renderStats(details.stats, match);
        renderLineup(details.lineup, match);
      })
      .catch(error => {
        if (serial !== requestId || error.name === 'AbortError') return;
        message('detailStats', 'آمار فعلاً در دسترس نیست؛ تایم‌لاین و صفحهٔ کامل مسابقه همچنان قابل مشاهده‌اند.');
        message('detailLineup', 'ترکیب تیم‌ها فعلاً در دسترس نیست؛ صفحهٔ کامل مسابقه را بررسی کن.');
      });
  }

  byId('detailScrim').addEventListener('click', close);
  closeButton.addEventListener('click', close);
  document.addEventListener('keydown', event => {
    if (overlay.hidden) return;
    if (event.key === 'Escape') { close(); return; }
    if (event.key !== 'Tab') return;
    const focusables = [...overlay.querySelectorAll('button:not([disabled]),a[href]:not([hidden])')]
      .filter(element => element.getClientRects().length);
    if (!focusables.length) return;
    const first = focusables[0], last = focusables[focusables.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  });
  for (const pane of panes) {
    byId('detailTab' + pane).addEventListener('click', () => chooseTab(pane));
  }
  window.MatchDetail = { open, close };
})();
