const http = require('http');
const fs = require('fs');
const path = require('path');

const root = __dirname;
const allowedHosts = new Set(['www.anten.ir', 'anten.ir', 'mapi.antenapi.com', 'www.aparatsport.com', 'aparatsport.com']);
const text = (value) => typeof value === 'string' ? value : '';
const mediaUrl = (value) => {
  try {
    const parsed = new URL(value);
    return parsed.protocol === 'https:' && parsed.hostname === 'match-cdn.varzesh3.ir' ? parsed.href : '';
  } catch { return ''; }
};
const highlightAsset = (value, host, extension) => {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && url.hostname === host && url.pathname.toLowerCase().endsWith(extension) ? url.href : '';
  } catch { return ''; }
};
const team = (value) => value ? { id: value.id, name: text(value.name), logo: mediaUrl(value.logo) } : null;
const statValue = (value) => value ? { value: String(value.value ?? ''), percent: Number(value.percent) || 0, extraValue: text(value.extraValue) } : null;
const stat = (value) => value ? { title: text(value.title), host: statValue(value.host), guest: statValue(value.guest) } : null;
const player = (value) => ({
  name: text(value?.name),
  shirtNumber: value?.shirtNumber ?? null,
  isCaptain: Boolean(value?.isCaptain),
  portrait: mediaUrl(value?.portrait),
  score: value?.score ?? null,
  isManOfTheMatch: Boolean(value?.isManOfTheMatch)
});
const lineupSide = (value) => value ? {
  formation: text(value.formation),
  coach: text(value.coach?.name),
  formationLines: (value.formationLines || []).map(line => ({ line: line.line, players: (line.players || []).map(player) })),
  benchedPlayers: (value.benchedPlayers || []).map(player)
} : null;

function findMatchData(value, id, depth = 0) {
  if (!value || typeof value !== 'object' || depth > 16) return null;
  if (value.id === id && value.host && value.guest && (value.lineup || value.stats)) return value;
  for (const child of Object.values(value)) {
    const found = findMatchData(child, id, depth + 1);
    if (found) return found;
  }
  return null;
}

function extractMatchData(html, id) {
  const scripts = /<script>self\.__next_f\.push\((\[1,[\s\S]*?\])\)<\/script>/g;
  for (const match of html.matchAll(scripts)) {
    if (!match[1].includes('lineup') && !match[1].includes('stats')) continue;
    try {
      const frame = JSON.parse(match[1]);
      if (typeof frame[1] !== 'string') continue;
      const separator = frame[1].indexOf(':');
      if (separator === -1) continue;
      const flightData = JSON.parse(frame[1].slice(separator + 1));
      const data = findMatchData(flightData, id);
      if (data) return data;
    } catch { /* Other Next.js frames can have different shapes. */ }
  }
  return null;
}

http.createServer(async (req, res) => {
  if (req.url === '/' || req.url === '/index.html') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    return fs.createReadStream(path.join(root, 'app-v2.html')).pipe(res);
  }
  if (req.url === '/assets/Vazirmatn.woff2') {
    res.writeHead(200, { 'Content-Type': 'font/woff2', 'Cache-Control': 'public, max-age=31536000, immutable' });
    return fs.createReadStream(path.join(root, 'assets', 'Vazirmatn.woff2')).pipe(res);
  }
  const staticFiles = {
    '/app-v2.html': ['app-v2.html', 'text/html; charset=utf-8', 'no-store'],
    '/app-v2.css': ['app-v2.css', 'text/css; charset=utf-8', 'no-store'],
    '/app-v2.js': ['app-v2.js', 'application/javascript; charset=utf-8', 'no-store'],
    '/detail-v2.js': ['detail-v2.js', 'application/javascript; charset=utf-8', 'no-store'],
    '/manifest.webmanifest': ['manifest.webmanifest', 'application/manifest+json', 'no-store'],
    '/sw.js': ['sw.js', 'application/javascript; charset=utf-8', 'no-store'],
    '/assets/icon-192.png': [path.join('assets', 'icon-192.png'), 'image/png', 'public, max-age=86400'],
    '/assets/icon-512.png': [path.join('assets', 'icon-512.png'), 'image/png', 'public, max-age=86400'],
    '/assets/icon-192-v2.png': [path.join('assets', 'icon-192-v2.png'), 'image/png', 'public, max-age=86400'],
    '/assets/icon-512-v2.png': [path.join('assets', 'icon-512-v2.png'), 'image/png', 'public, max-age=86400']
  };
  if (staticFiles[req.url]) {
    const [file, contentType, cacheControl] = staticFiles[req.url];
    res.writeHead(200, { 'Content-Type': contentType, 'Cache-Control': cacheControl });
    return fs.createReadStream(path.join(root, file)).pipe(res);
  }
  if (req.url === '/api/varzesh3/livescore') {
    try {
      const upstream = await fetch('https://web-api.varzesh3.ir/v2.0/livescore/today', {
        headers: { Accept: 'application/json' },
        signal: AbortSignal.timeout(15000)
      });
      const responseBody = await upstream.arrayBuffer();
      res.writeHead(upstream.status, { 'Content-Type': upstream.headers.get('content-type') || 'application/json', 'Access-Control-Allow-Origin': 'http://localhost:8787', 'Cache-Control': 'no-store' });
      return res.end(Buffer.from(responseBody));
    } catch (error) {
      res.writeHead(502, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': 'http://localhost:8787' });
      return res.end(JSON.stringify({ error: error.message || 'دریافت نتایج زنده ناموفق بود.' }));
    }
  }
  if (req.url.startsWith('/api/varzesh3/video/')) {
    const videoId = req.url.slice('/api/varzesh3/video/'.length);
    if (!/^\d+$/.test(videoId)) {
      res.writeHead(400, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      return res.end(JSON.stringify({ error: 'شناسهٔ ویدئو نامعتبر است.' }));
    }
    try {
      const upstream = await fetch(`https://video.varzesh3.ir/video/${videoId}/`, {
        headers: { Accept: 'text/html' }, signal: AbortSignal.timeout(15000)
      });
      if (!upstream.ok) throw new Error(`HTTP ${upstream.status}`);
      const html = await upstream.text();
      if (html.length > 2_000_000) throw new Error('پاسخ صفحهٔ ویدئو بیش از حد بزرگ است.');
      let metadata = null;
      for (const script of html.matchAll(/<script\b[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)) {
        try {
          const data = JSON.parse(script[1]);
          const candidates = Array.isArray(data) ? data : (data['@graph'] || [data]);
          metadata = candidates.find(item => item?.['@type'] === 'VideoObject');
          if (metadata) break;
        } catch { /* Other JSON-LD blocks can have different shapes. */ }
      }
      const src = highlightAsset(metadata?.contentUrl, 'video-vcdn.varzesh3.ir', '.mp4');
      if (!src) throw new Error('فایل قابل پخش برای این صحنه پیدا نشد.');
      const thumbnail = Array.isArray(metadata.thumbnailUrl) ? metadata.thumbnailUrl[0] : metadata.thumbnailUrl;
      const poster = highlightAsset(thumbnail, 'video-icdn.varzesh3.ir', '.png') ||
        highlightAsset(thumbnail, 'video-icdn.varzesh3.ir', '.jpg') ||
        highlightAsset(thumbnail, 'video-icdn.varzesh3.ir', '.webp');
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      return res.end(JSON.stringify({ id: Number(videoId), title: text(metadata.name), src, poster }));
    } catch (error) {
      res.writeHead(502, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      return res.end(JSON.stringify({ error: error.message || 'دریافت ویدئوی صحنه ناموفق بود.' }));
    }
  }
  if (req.url.startsWith('/api/varzesh3/match/')) {
    const matchId = req.url.slice('/api/varzesh3/match/'.length);
    if (!/^\d+$/.test(matchId)) {
      res.writeHead(400, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      return res.end(JSON.stringify({ error: 'شناسهٔ مسابقه نامعتبر است.' }));
    }
    try {
      const upstream = await fetch(`https://www.varzesh3.ir/football/match/${matchId}/`, {
        headers: { Accept: 'text/html' }, signal: AbortSignal.timeout(18000)
      });
      if (!upstream.ok) throw new Error(`HTTP ${upstream.status}`);
      const html = await upstream.text();
      if (html.length > 2_000_000) throw new Error('پاسخ صفحه بیش از حد بزرگ است.');
      const data = extractMatchData(html, Number(matchId));
      if (!data) throw new Error('ساختار جزئیات مسابقه در صفحه پیدا نشد.');
      const result = {
        id: data.id,
        title: text(data.title),
        date: text(data.date),
        time: text(data.time),
        statusTitle: text(data.statusTitle),
        isLive: Boolean(data.isLive),
        liveTime: text(data.liveTime),
        referee: text(data.referee),
        stadium: text(data.stadium),
        week: data.week ?? null,
        league: data.league ? { title: text(data.league.title), season: text(data.league.season), logo: mediaUrl(data.league.logo) } : null,
        host: team(data.host),
        guest: team(data.guest),
        goals: data.goals ? { host: data.goals.host ?? null, guest: data.goals.guest ?? null } : null,
        stats: (data.stats || []).map(section => ({
          title: text(section.title),
          isActive: Boolean(section.isActive),
          possession: stat(section.stats?.possession),
          items: (section.stats?.items || []).map(stat).filter(Boolean)
        })),
        lineup: data.lineup ? { host: lineupSide(data.lineup.host), guest: lineupSide(data.lineup.guest) } : null,
        pageUrl: upstream.url
      };
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      return res.end(JSON.stringify(result));
    } catch (error) {
      res.writeHead(502, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      return res.end(JSON.stringify({ error: error.message || 'جزئیات بازی دریافت نشد.' }));
    }
  }
  if (req.url.startsWith('/api/varzesh3/events/')) {
    try {
      const matchId = req.url.slice('/api/varzesh3/events/'.length);
      if (!/^\d+$/.test(matchId)) throw new Error('شناسهٔ مسابقه نامعتبر است.');
      const upstream = await fetch(`https://web-api.varzesh3.ir/v2.0/livescore/football/matches/${matchId}/events`, {
        headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(15000)
      });
      const responseBody = await upstream.arrayBuffer();
      res.writeHead(upstream.status, { 'Content-Type': upstream.headers.get('content-type') || 'application/json', 'Access-Control-Allow-Origin': 'http://localhost:8787', 'Cache-Control': 'no-store' });
      return res.end(Buffer.from(responseBody));
    } catch (error) {
      res.writeHead(400, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': 'http://localhost:8787' });
      return res.end(JSON.stringify({ error: error.message || 'دریافت جزئیات مسابقه ناموفق بود.' }));
    }
  }
  if (req.url === '/api/salin/sports') {
    try {
      if (!process.env.SALIN_API_TOKEN || !process.env.SALIN_INSTALL_UUID) throw new Error('API جدید سالین به نشست مجازِ دستگاه نیاز دارد. آن را در بک‌اند خود پیکربندی کنید.');
      const upstream = await fetch('https://cms.ardanmi.com/api/v1/channels?category_slugs%5B%5D=sports&per_page=100&page=1', {
        headers: {
          Accept: 'application/json',
          Authorization: `Bearer ${process.env.SALIN_API_TOKEN}`,
          'X-App-Platform': 'android',
          'X-Install-UUID': process.env.SALIN_INSTALL_UUID,
          'X-App-Version': '2.0.10',
          'X-App-Build': '167'
        },
        signal: AbortSignal.timeout(15000)
      });
      const responseBody = await upstream.arrayBuffer();
      res.writeHead(upstream.status, { 'Content-Type': upstream.headers.get('content-type') || 'application/json', 'Access-Control-Allow-Origin': 'http://localhost:8787' });
      return res.end(Buffer.from(responseBody));
    } catch (error) {
      res.writeHead(503, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': 'http://localhost:8787' });
      return res.end(JSON.stringify({ error: error.message || 'دریافت فهرست سالین ناموفق بود.' }));
    }
  }
  if (!req.url.startsWith('/api?')) { res.writeHead(404); return res.end('Not found'); }
  try {
    const target = new URL(new URL(req.url, 'http://localhost').searchParams.get('url'));
    if (target.protocol !== 'https:' || !allowedHosts.has(target.hostname)) throw new Error('این میزبان مجاز نیست');
    const headers = { Accept: 'application/json' };
    const auth = req.headers.authorization;
    if (auth) headers.Authorization = auth;
    const upstream = await fetch(target, { headers });
    const body = await upstream.arrayBuffer();
    res.writeHead(upstream.status, { 'Content-Type': upstream.headers.get('content-type') || 'application/json', 'Access-Control-Allow-Origin': 'http://localhost:8787' });
    res.end(Buffer.from(body));
  } catch (error) {
    res.writeHead(502, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': 'http://localhost:8787' });
    res.end(JSON.stringify({ error: error.message }));
  }
}).listen(8787, '127.0.0.1', () => console.log('Test app: http://localhost:8787'));
