const $ = id => document.getElementById(id);
const sourceUrls = {
  anten: 'https://www.anten.ir/mapi/v1/v4.3/programs',
  aparat: 'https://www.aparatsport.com/api/fa/v1/sport/sport/get_today_match_data?uuid=',
  salin: '/api/salin/sports',
  daddy: ''
};
const sourceNames = { anten:'آنتن', aparat:'آپارات اسپرت', salin:'سالین‌تی‌وی', daddy:'کانال ۶۱' };
const sourceNotes = {
  anten:'برنامه‌های آنتن از مسیر فعلی دریافت می‌شوند.',
  aparat:'مسابقات امروز آپارات اسپرت دریافت می‌شوند.',
  salin:'سالین‌تی‌وی برای دریافت شبکه‌ها به نشست معتبر بک‌اند نیاز دارد.',
  daddy:'کانال ۶۱ در پلیر رسمی خودش باز می‌شود.'
};
const demoPrograms = [
  { id:101, title:'تیم الف — تیم ب', time:'امروز، ۲۰:۰۰', live:true },
  { id:102, title:'تیم ج — تیم د', time:'امروز، ۲۲:۳۰', live:true },
  { id:103, title:'تیم هـ — تیم و', time:'فردا، ۱۸:۰۰', live:false }
];
const screens = { home:$('screen-home'), scores:$('screen-scores'), sources:$('screen-sources') };
const scrollPositions = { home:0, scores:0, sources:0 };
let activeView = 'home', currentSource = 'anten', programs = [], allLeagues = [];
let broadcastMode = true, broadcastGames = [], broadcastSerial = 0, selectedGame = null;
let scoreFilter = 'live', scoreFilterTouched = false, lastScoreUpdate = '', liveLoading = false, loadSerial = 0, selectionSerial = 0;
let activeQualities = [], hlsPlayer = null, featuredMatches = [], sliderIndex = 0, sliderScrollFrame = 0;

function switchView(view, options = {}) {
  if (!screens[view]) return;
  const scroller = $('contentScroll');
  const wasActive = activeView === view;
  if (activeView === view) {
    if (options.toTop) scroller.scrollTo({ top:0, behavior:'smooth' });
  } else {
    scrollPositions[activeView] = scroller.scrollTop;
    screens[activeView].hidden = true;
    screens[view].hidden = false;
    activeView = view;
    document.querySelectorAll('.tab-button').forEach(button => button.setAttribute('aria-selected', String(button.dataset.view === view)));
    requestAnimationFrame(() => { scroller.scrollTop = options.toTop ? 0 : scrollPositions[view]; });
  }
  if (options.history && !wasActive) history.pushState({ view }, '', view === 'home' ? location.pathname : '#' + view);
}
document.querySelectorAll('.tab-button').forEach(button => button.onclick = () => switchView(button.dataset.view, { history:true, toTop:activeView === button.dataset.view }));
window.addEventListener('popstate', () => switchView(screens[location.hash.slice(1)] ? location.hash.slice(1) : 'home'));
$('goSources').onclick = () => switchView('sources', { history:true, toTop:true });

function programName(program) { return program.titleProgram || program.title || program.name || 'برنامه'; }
function programId(program) { return program.programId || program.id; }
function clearMedia() {
  selectionSerial += 1;
  if (hlsPlayer) { hlsPlayer.destroy(); hlsPlayer = null; }
  const video = $('player'); video.pause(); video.removeAttribute('src'); video.load(); video.hidden = true;
  $('embedPlayer').removeAttribute('src'); $('embedPlayer').hidden = true;
  $('playerEmpty').hidden = false; $('quality').hidden = true; $('hlsQuality').hidden = true;
  activeQualities = [];
}
function renderPrograms(items) {
  programs = items;
  $('programCount').textContent = items.length.toLocaleString('fa-IR');
  const container = $('matches'); container.replaceChildren();
  if (!items.length) {
    const empty = document.createElement('div'); empty.className = 'empty-state'; empty.textContent = 'هنوز برنامه‌ای در این منبع دیده نمی‌شود.';
    container.append(empty); return;
  }
  items.forEach(program => {
    const button = document.createElement('button'); button.type = 'button'; button.className = 'program-item';
    const mark = document.createElement('span'); mark.className = 'program-mark'; mark.textContent = program.live || program.isLive ? '●' : '▶';
    const body = document.createElement('span'); body.className = 'program-text';
    const title = document.createElement('strong'); title.textContent = programName(program);
    const sub = document.createElement('small'); sub.textContent = program.time || program.date || 'جزئیات پخش';
    body.append(title, sub);
    const arrow = document.createElement('span'); arrow.className = 'program-arrow'; arrow.textContent = '←';
    button.append(mark, body, arrow);
    button.onclick = () => {
      container.querySelectorAll('.program-item.active').forEach(item => item.classList.remove('active'));
      button.classList.add('active'); selectProgram(program);
      document.querySelector('.player-panel').scrollIntoView({ behavior:'smooth', block:'start' });
    };
    container.append(button);
  });
}
function cleanGameName(value) {
  return String(value || '').replace(/^.*?:\s*/, '').replace(/^(فوتبال|بسکتبال|والیبال|اسنوکر)\s+/, '').replace(/\s*\([^)]*\)\s*$/, '').trim();
}
function gameKey(value) {
  return cleanGameName(value).normalize('NFKC').toLowerCase().replace(/ي/g,'ی').replace(/ك/g,'ک').replace(/[–—]/g,'-').replace(/\s+/g,' ').replace(/\s*-\s*/g,'|');
}
function renderBroadcastGames() {
  const container = $('matches'); container.replaceChildren();
  $('programCount').textContent = broadcastGames.length.toLocaleString('fa-IR');
  if (!broadcastGames.length) {
    const empty = document.createElement('div'); empty.className = 'empty-state'; empty.textContent = 'بازی قابل پخشی فعلاً پیدا نشد.'; container.append(empty); return;
  }
  broadcastGames.forEach(game => {
    const button = document.createElement('button'); button.type = 'button'; button.className = 'program-item';
    const mark = document.createElement('span'); mark.className = 'program-mark'; mark.textContent = '▶';
    const body = document.createElement('span'); body.className = 'program-text';
    const title = document.createElement('strong'); title.textContent = game.title;
    const sub = document.createElement('small'); sub.textContent = [game.time, Object.keys(game.sources).map(source => sourceNames[source]).join(' · ')].filter(Boolean).join('  ·  ');
    const arrow = document.createElement('span'); arrow.className = 'program-arrow'; arrow.textContent = '←';
    body.append(title, sub); button.append(mark, body, arrow);
    button.onclick = () => openWatchChooser(game);
    container.append(button);
  });
}
function extractPrograms(payload, source = currentSource) {
  if (source === 'aparat') {
    const raw = Array.isArray(payload) ? payload : (payload.data || payload.matches || []);
    const list = raw.flatMap(item => item.match_detail || item.match || [item]);
    return list.map(item => ({ ...item, id:item.uuid || item.id, title:item.title || item.match_title || item.team1_name || 'مسابقه', time:item.start_time_date || item.start_time || '' }));
  }
  if (source === 'salin') {
    const list = Array.isArray(payload) ? payload : (payload.data || payload.items || []);
    return list.map(item => ({ ...item, id:item.channel_id || item.unique_code, title:item.channel_name || item.name || 'شبکهٔ ورزشی', time:item.channel_language || 'پخش زنده' }));
  }
  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload?.data)) return payload.data;
  if (Array.isArray(payload?.programs)) return payload.programs;
  if (Array.isArray(payload?.items)) return payload.items.map(item => item.program || item);
  if (Array.isArray(payload?.calendar)) return payload.calendar.flatMap(day => (day.items || []).map(item => ({ ...(item.program || item), time:item.time || item.program?.time || day.date })));
  return [];
}
async function getJSON(url) {
  const token = $('token').value.trim();
  const headers = { Accept:'application/json' };
  if (token && !url.startsWith('/api/')) headers.Authorization = 'Bearer ' + token;
  const target = url.startsWith('/api/') ? url : '/api?url=' + encodeURIComponent(url);
  const response = await fetch(target, { headers, cache:'no-store' });
  if (!response.ok) {
    const errorBody = await response.json().catch(() => ({}));
    const error = new Error(errorBody.error || 'HTTP ' + response.status);
    error.status = response.status; throw error;
  }
  return response.json();
}
async function loadBroadcastGames() {
  const serial = ++broadcastSerial;
  $('load').disabled = true; $('status').textContent = 'در حال دریافت بازی‌ها…';
  const results = await Promise.allSettled(['anten','aparat'].map(async source => ({ source, items:extractPrograms(await getJSON(sourceUrls[source]), source) })));
  if (serial !== broadcastSerial || !broadcastMode) return;
  const merged = new Map();
  results.forEach(result => {
    if (result.status !== 'fulfilled') return;
    const { source, items } = result.value;
    items.forEach(program => {
      const title = cleanGameName(programName(program));
      const key = gameKey(title) || source + ':' + programId(program);
      if (!merged.has(key)) merged.set(key, { title, time:program.time || program.date || '', sources:{} });
      merged.get(key).sources[source] = program;
    });
  });
  broadcastGames = [...merged.values()];
  renderBroadcastGames();
  const failures = results.filter(result => result.status === 'rejected').length;
  $('status').textContent = broadcastGames.length.toLocaleString('fa-IR') + ' بازی' + (failures ? ' · دریافت ' + failures.toLocaleString('fa-IR') + ' منبع ناموفق بود' : '');
  $('load').disabled = false;
}
async function loadPrograms() {
  const serial = ++loadSerial, source = currentSource;
  $('load').disabled = true; $('status').textContent = 'در حال دریافت فهرست…';
  try {
    const list = source === 'daddy' ? [{ id:61, title:'کانال ۶۱', time:'پخش زنده · پلیر رسمی' }] : extractPrograms(await getJSON($('listUrl').value));
    if (serial !== loadSerial || source !== currentSource) return;
    renderPrograms(list);
    $('status').textContent = list.length.toLocaleString('fa-IR') + ' برنامه دریافت شد.';
  } catch (error) {
    if (serial !== loadSerial) return;
    renderPrograms([]); $('status').textContent = 'خطا در اتصال: ' + error.message;
  } finally { if (serial === loadSerial) $('load').disabled = false; }
}
function setSource(source) {
  if (!sourceUrls.hasOwnProperty(source)) return;
  broadcastMode = source === 'anten' || source === 'aparat';
  ++loadSerial;
  currentSource = source; $('listUrl').value = sourceUrls[source]; $('listUrl').disabled = source === 'daddy'; $('token').disabled = source === 'daddy';
  $('currentSourceLabel').textContent = broadcastMode ? 'آنتن و آپارات اسپرت' : 'منبع: ' + sourceNames[source];
  $('sourceNote').textContent = sourceNotes[source];
  document.querySelectorAll('.source-option').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.source === source)));
  clearMedia(); $('playerTitle').textContent = 'پخش موردنظرت را انتخاب کن'; $('playerMeta').textContent = 'پخش پس از انتخاب برنامه آماده می‌شود.';
  if (broadcastMode) { $('programTitle').textContent = 'بازی‌های قابل پخش'; loadBroadcastGames(); }
  else { ++broadcastSerial; $('programTitle').textContent = 'برنامه‌های پخش'; renderPrograms([]); loadPrograms(); }
}
document.querySelectorAll('.source-option').forEach(button => button.onclick = () => {
  setSource(button.dataset.source);
  switchView('home', { history:true, toTop:true });
});
$('load').onclick = () => broadcastMode ? loadBroadcastGames() : loadPrograms();
$('demo').onclick = () => {
  ++loadSerial; ++broadcastSerial; broadcastMode = false; $('load').disabled = false; clearMedia(); renderPrograms(demoPrograms);
  $('status').textContent = 'دادهٔ نمونه نمایش داده شد.';
  switchView('home', { history:true, toTop:true });
};

function closeWatchChooser() {
  $('watchChooser').hidden = true;
  selectedGame = null;
}
function openWatchChooser(game) {
  selectedGame = game;
  $('watchTitle').textContent = game.title;
  document.querySelectorAll('[data-watch-source]').forEach(button => {
    const available = Boolean(game.sources[button.dataset.watchSource]);
    button.disabled = !available;
    button.querySelector('span').textContent = available ? 'پخش بازی ←' : 'در دسترس نیست';
  });
  $('watchHint').textContent = 'منبعی را انتخاب کن که برای این بازی پخش دارد.';
  $('watchChooser').hidden = false;
  $('closeWatch').focus({ preventScroll:true });
}
$('closeWatch').onclick = closeWatchChooser;
$('watchScrim').onclick = closeWatchChooser;
document.querySelectorAll('[data-watch-source]').forEach(button => button.onclick = () => {
  const game = selectedGame, source = button.dataset.watchSource;
  if (!game?.sources[source]) return;
  closeWatchChooser();
  currentSource = source;
  $('listUrl').value = sourceUrls[source];
  $('currentSourceLabel').textContent = 'پخش از ' + sourceNames[source];
  document.querySelectorAll('.source-option').forEach(option => option.setAttribute('aria-pressed', String(option.dataset.source === source)));
  $('playerTitle').textContent = game.title;
  selectProgram(game.sources[source]);
  document.querySelector('.player-panel').scrollIntoView({ behavior:'smooth', block:'start' });
});
document.addEventListener('keydown', event => { if (event.key === 'Escape' && !$('watchChooser').hidden) closeWatchChooser(); });

async function playStream(index, serial = selectionSerial) {
  const quality = activeQualities[index]; if (!quality) return;
  $('playerMeta').textContent = 'در حال آماده‌سازی پخش…'; $('hlsQuality').hidden = true;
  try {
    let url = quality.directUrl;
    if (!url) { const access = await getJSON(quality.accessUrl); url = (access.data || access).url; }
    if (serial !== selectionSerial) return;
    if (!url) throw new Error('لینک پخش دریافت نشد.');
    const video = $('player');
    if (hlsPlayer) { hlsPlayer.destroy(); hlsPlayer = null; }
    video.hidden = false; $('playerEmpty').hidden = true;
    if (/\.m3u8(?:\?|$)/i.test(url) && window.Hls?.isSupported()) {
      hlsPlayer = new Hls(); hlsPlayer.loadSource(url); hlsPlayer.attachMedia(video);
      hlsPlayer.on(Hls.Events.MANIFEST_PARSED, (_, data) => {
        if (serial !== selectionSerial) return;
        const picker = $('hlsQuality'); picker.replaceChildren(new Option('کیفیت خودکار', '-1'));
        data.levels.forEach((level, levelIndex) => picker.append(new Option(level.height ? level.height + 'p' : Math.round(level.bitrate / 1000) + ' kbps', String(levelIndex))));
        picker.hidden = data.levels.length < 2;
        video.play().catch(() => { $('playerMeta').textContent = 'برای شروع، دکمهٔ پخش را لمس کن.'; });
      });
      hlsPlayer.on(Hls.Events.ERROR, (_, data) => { if (serial === selectionSerial && data.fatal) $('playerMeta').textContent = 'خطا در پخش: ' + data.details; });
    } else {
      video.src = url;
      video.play().catch(() => { $('playerMeta').textContent = 'برای شروع، دکمهٔ پخش را لمس کن.'; });
    }
    $('playerMeta').textContent = quality.label + ' آمادهٔ پخش است.';
  } catch (error) { if (serial === selectionSerial) $('playerMeta').textContent = 'خطا در پخش: ' + error.message; }
}
async function selectProgram(program) {
  clearMedia(); const serial = selectionSerial, source = currentSource;
  $('playerTitle').textContent = programName(program); $('playerMeta').textContent = 'در حال بررسی دسترسی پخش…';
  if (demoPrograms.includes(program)) { $('playerMeta').textContent = 'این برنامه نمونه است و ویدئو ندارد.'; return; }
  if (source === 'daddy') {
    $('embedPlayer').src = 'https://thedaddy.li/stream/stream-61.php';
    $('embedPlayer').hidden = false; $('playerEmpty').hidden = true;
    $('playerMeta').textContent = 'کانال ۶۱ در پلیر رسمی باز شد.';
    return;
  }
  try {
    let qualities = [];
    if (source === 'aparat') {
      const response = await getJSON('https://www.aparatsport.com/api/fa/v1/sport/sport/get_match_with_uuid?uuid=' + encodeURIComponent(programId(program)));
      const data = response.data || response;
      qualities = [data.m3u8 ? { label:'پخش اصلی', directUrl:data.m3u8 } : null, ...(data.other_language || []).map((item, i) => item.m3u8 ? { label:item.reporter_name || item.title || 'گزارش ' + (i + 1), directUrl:item.m3u8 } : null)].filter(Boolean);
    } else if (source === 'salin') {
      qualities = [program.channel_address ? { label:'پخش اصلی', directUrl:program.channel_address } : null, program.channel_second_address ? { label:'پخش جایگزین', directUrl:program.channel_second_address } : null].filter(Boolean);
    } else {
      const base = $('listUrl').value.split('/programs')[0]; let detail;
      try { detail = await getJSON(base + '/programs/details/' + programId(program)); }
      catch (error) { if (error.status !== 404) throw error; detail = await getJSON(base + '/programs/' + programId(program)); }
      const data = detail.data || detail, streams = data.streams || data.program?.streams || [];
      qualities = streams.flatMap(stream => [stream.hqUrlAccess ? { label:'کیفیت بالا', accessUrl:stream.hqUrlAccess } : null, stream.lowUrlAccess ? { label:'مصرف کمتر', accessUrl:stream.lowUrlAccess } : null].filter(Boolean));
    }
    if (serial !== selectionSerial || source !== currentSource) return;
    activeQualities = qualities;
    if (!activeQualities.length) throw new Error('کیفیتی برای این پخش پیدا نشد.');
    const picker = $('quality'); picker.replaceChildren();
    activeQualities.forEach((quality, i) => picker.append(new Option(quality.label, String(i))));
    picker.value = '0'; picker.hidden = false;
    await playStream(0, serial);
  } catch (error) { if (serial === selectionSerial) $('playerMeta').textContent = error.status === 404 ? 'این پخش فعلاً در دسترس نیست.' : 'خطا: ' + error.message; }
}
$('quality').onchange = event => playStream(Number(event.target.value));
$('hlsQuality').onchange = event => { if (hlsPlayer) hlsPlayer.currentLevel = Number(event.target.value); };

function safeLogo(url) {
  try { const parsed = new URL(url); return parsed.protocol === 'https:' && parsed.hostname === 'match-cdn.varzesh3.ir' ? parsed.href : ''; }
  catch { return ''; }
}
function teamChip(team, fallback) {
  const wrap = document.createElement('span'); wrap.className = 'team';
  const logo = safeLogo(team?.logo);
  const badge = document.createElement(logo ? 'img' : 'span');
  if (logo) { badge.src = logo; badge.alt = ''; badge.loading = 'lazy'; }
  else { badge.className = 'team-fallback'; badge.textContent = '●'; }
  const name = document.createElement('span'); name.textContent = team?.name || fallback;
  wrap.append(badge, name); return wrap;
}
function scoreNode(match, className = 'score') {
  const score = document.createElement('strong'); score.className = className;
  for (const value of [match.goals?.host ?? '–', ':', match.goals?.guest ?? '–']) {
    const cell = document.createElement('span'); cell.textContent = value; score.append(cell);
  }
  return score;
}
function matchState(match) {
  return match.isLive ? '● زنده ' + (match.liveTime || '') : match.goals ? (match.statusTitle || 'پایان بازی') : (match.time || 'در انتظار شروع');
}
function allMatchEntries() {
  return allLeagues.flatMap(league => (league.dates || []).flatMap(day => (day.matches || []).map(match => ({ match, league:league.title, sport:league.sport }))));
}
function makeScoreCard(entry) {
  const { match, league, sport } = entry;
  const card = document.createElement('button'); card.type = 'button'; card.className = 'score-card';
  const top = document.createElement('div'); top.className = 'score-card-top';
  const status = document.createElement('span'); status.className = match.isLive ? 'score-state live' : 'score-state'; status.textContent = matchState(match);
  const date = document.createElement('span'); date.textContent = match.date || '';
  top.append(status, date);
  const line = document.createElement('div'); line.className = 'scoreline';
  line.append(teamChip(match.host, 'میزبان'), scoreNode(match), teamChip(match.guest, 'میهمان'));
  const foot = document.createElement('div'); foot.className = 'score-card-foot'; foot.textContent = 'جزئیات بازی ←';
  card.append(top, line, foot);
  card.setAttribute('aria-label', (match.host?.name || 'میزبان') + ' ' + (match.goals?.host ?? 'بدون نتیجه') + ' به ' + (match.goals?.guest ?? 'بدون نتیجه') + ' ' + (match.guest?.name || 'میهمان') + '، جزئیات');
  card.onclick = () => window.MatchDetail.open(match, league, sport);
  return card;
}
function renderScores() {
  const list = $('liveResults'); list.replaceChildren();
  const entries = allMatchEntries().filter(entry => scoreFilter === 'all' || entry.match.isLive);
  $('liveCount').textContent = allMatchEntries().filter(entry => entry.match.isLive).length.toLocaleString('fa-IR');
  const grouped = new Map();
  entries.forEach(entry => { if (!grouped.has(entry.league)) grouped.set(entry.league, []); grouped.get(entry.league).push(entry); });
  if (!grouped.size) {
    const empty = document.createElement('div'); empty.className = 'empty-state';
    empty.textContent = scoreFilter === 'live' ? 'الان بازی زنده‌ای ثبت نشده. «همهٔ بازی‌ها» را ببین.' : 'مسابقه‌ای در فهرست امروز نیست.';
    list.append(empty);
  }
  for (const [league, matches] of grouped) {
    const section = document.createElement('section'); section.className = 'league-section';
    const head = document.createElement('div'); head.className = 'league-label';
    const name = document.createElement('h2'); name.textContent = league || 'مسابقات';
    const count = document.createElement('span'); count.textContent = matches.length.toLocaleString('fa-IR') + ' بازی';
    head.append(name, count);
    const cards = document.createElement('div'); cards.className = 'league-games';
    matches.forEach(entry => cards.append(makeScoreCard(entry)));
    section.append(head, cards); list.append(section);
  }
  const label = scoreFilter === 'live' ? 'بازی در جریان' : 'بازی در فهرست';
  $('liveStatus').textContent = entries.length.toLocaleString('fa-IR') + ' ' + label + (lastScoreUpdate ? ' · ' + lastScoreUpdate : '');
}
function setScoreFilter(filter, touched = true) {
  scoreFilter = filter;
  if (touched) scoreFilterTouched = true;
  $('filterLive').setAttribute('aria-pressed', String(filter === 'live'));
  $('filterAll').setAttribute('aria-pressed', String(filter === 'all'));
  renderScores();
}
$('filterLive').onclick = () => setScoreFilter('live');
$('filterAll').onclick = () => setScoreFilter('all');

function renderFeatured() {
  const entries = allMatchEntries();
  const now = Date.now();
  const live = entries.filter(entry => entry.match.isLive);
  const upcoming = entries.filter(entry => !entry.match.isLive && !entry.match.goals && Date.parse(entry.match.startOnUtc) >= now).sort((a, b) => Date.parse(a.match.startOnUtc) - Date.parse(b.match.startOnUtc));
  const finished = entries.filter(entry => !entry.match.isLive && entry.match.goals);
  featuredMatches = [...live, ...upcoming, ...finished].slice(0, 7);
  sliderIndex = Math.min(sliderIndex, Math.max(0, featuredMatches.length - 1));
  const rail = $('sliderRail'), dots = $('sliderDots'), priorScroll = rail.scrollLeft;
  rail.replaceChildren(); dots.replaceChildren();
  if (!featuredMatches.length) {
    const empty = document.createElement('div'); empty.className = 'empty-state'; empty.textContent = 'بازی‌های منتخب پس از دریافت نتایج نمایش داده می‌شوند.'; rail.append(empty); return;
  }
  featuredMatches.forEach((entry, index) => {
    const { match, league, sport } = entry;
    const slide = document.createElement('button'); slide.type = 'button'; slide.className = 'slide';
    const top = document.createElement('div'); top.className = 'slide-top';
    const leagueText = document.createElement('span'); leagueText.textContent = league || 'مسابقه';
    const state = document.createElement('span'); state.className = match.isLive ? 'live' : ''; state.textContent = matchState(match);
    top.append(leagueText, state);
    const teams = document.createElement('div'); teams.className = 'slide-teams';
    teams.append(teamChip(match.host, 'میزبان'), scoreNode(match, 'slide-score'), teamChip(match.guest, 'میهمان'));
    const bottom = document.createElement('div'); bottom.className = 'slide-bottom';
    const date = document.createElement('span'); date.textContent = match.date || '';
    const more = document.createElement('span'); more.textContent = 'جزئیات ←';
    bottom.append(date, more); slide.append(top, teams, bottom);
    slide.setAttribute('aria-label', 'جزئیات بازی ' + (match.host?.name || '') + ' و ' + (match.guest?.name || ''));
    slide.onclick = () => window.MatchDetail.open(match, league, sport);
    rail.append(slide);
    const dot = document.createElement('button'); dot.type = 'button'; dot.setAttribute('aria-label', 'اسلاید ' + (index + 1));
    dot.onclick = () => goSlide(index); dots.append(dot);
  });
  updateSliderDots();
  requestAnimationFrame(() => { rail.scrollLeft = priorScroll; });
}
function updateSliderDots() {
  [...$('sliderDots').children].forEach((dot, index) => dot.setAttribute('aria-current', String(index === sliderIndex)));
  $('sliderPrev').disabled = featuredMatches.length < 2;
  $('sliderNext').disabled = featuredMatches.length < 2;
}
function goSlide(index) {
  if (!featuredMatches.length) return;
  sliderIndex = (index + featuredMatches.length) % featuredMatches.length;
  $('sliderRail').children[sliderIndex]?.scrollIntoView({ behavior:'smooth', block:'nearest', inline:'center' });
  updateSliderDots();
}
$('sliderPrev').onclick = () => goSlide(sliderIndex - 1);
$('sliderNext').onclick = () => goSlide(sliderIndex + 1);
$('sliderRail').addEventListener('scroll', () => {
  cancelAnimationFrame(sliderScrollFrame);
  sliderScrollFrame = requestAnimationFrame(() => {
    const rail = $('sliderRail'), center = rail.getBoundingClientRect().left + rail.clientWidth / 2;
    let nearest = 0, distance = Infinity;
    [...rail.children].forEach((child, index) => {
      const rect = child.getBoundingClientRect(), delta = Math.abs(rect.left + rect.width / 2 - center);
      if (delta < distance) { distance = delta; nearest = index; }
    });
    sliderIndex = nearest; updateSliderDots();
  });
}, { passive:true });

async function loadLiveResults() {
  if (liveLoading) return;
  liveLoading = true; $('refreshLive').disabled = true;
  if (!allLeagues.length) $('liveStatus').textContent = 'در حال دریافت نتایج…';
  try {
    const response = await fetch('/api/varzesh3/livescore', { cache:'no-store' });
    if (!response.ok) throw new Error('HTTP ' + response.status);
    const data = await response.json();
    allLeagues = Array.isArray(data) ? data : [];
    lastScoreUpdate = new Date().toLocaleTimeString('fa-IR');
    if (!scoreFilterTouched) setScoreFilter(allMatchEntries().some(entry => entry.match.isLive) ? 'live' : 'all', false);
    else renderScores();
    renderFeatured();
  } catch (error) {
    $('liveStatus').textContent = 'خطا در دریافت: ' + error.message;
    if (!allLeagues.length) { renderScores(); renderFeatured(); }
  } finally { liveLoading = false; $('refreshLive').disabled = false; }
}
$('refreshLive').onclick = loadLiveResults;

let installPrompt = null, toastTimer = null;
function showToast(message) {
  $('toast').textContent = message; $('toast').hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { $('toast').hidden = true; }, 6500);
}
window.addEventListener('beforeinstallprompt', event => { event.preventDefault(); installPrompt = event; });
window.addEventListener('appinstalled', () => { installPrompt = null; showToast('خط بازی به صفحهٔ اصلی اضافه شد.'); });
$('installApp').onclick = async () => {
  if (installPrompt) { await installPrompt.prompt(); installPrompt = null; }
  else if (/iPhone|iPad|iPod/.test(navigator.userAgent)) showToast('در Safari از «اشتراک‌گذاری» گزینهٔ «افزودن به صفحهٔ اصلی» را بزن.');
  else showToast('در Chrome از منوی ⋮ گزینهٔ «نصب برنامه» را بزن. روی گوشی، آدرس HTTPS یا localhost لازم است.');
};
if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));

const initialView = screens[location.hash.slice(1)] ? location.hash.slice(1) : 'home';
if (initialView !== 'home') switchView(initialView);
renderPrograms([]); loadBroadcastGames(); renderFeatured(); loadLiveResults();
setInterval(loadLiveResults, 60000);
