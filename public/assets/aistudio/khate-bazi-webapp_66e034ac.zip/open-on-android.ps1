$ErrorActionPreference = 'Stop'

try {
    Invoke-WebRequest -UseBasicParsing 'http://127.0.0.1:8787/' -TimeoutSec 3 | Out-Null
} catch {
    throw 'ابتدا سرور را با node server.js اجرا کنید.'
}

$connectedDevices = @(& adb devices | Select-String '^\S+\s+device$')
if ($LASTEXITCODE -ne 0 -or $connectedDevices.Count -ne 1) {
    throw 'یک گوشی اندرویدی را با USB و USB debugging مجاز وصل کنید.'
}

& adb reverse tcp:8787 tcp:8787
if ($LASTEXITCODE -ne 0) { throw 'اتصال پورت محلی گوشی برقرار نشد.' }

& adb shell am start -a android.intent.action.VIEW -d 'http://localhost:8787/'
if ($LASTEXITCODE -ne 0) { throw 'باز کردن وب‌اپ روی گوشی ناموفق بود.' }
